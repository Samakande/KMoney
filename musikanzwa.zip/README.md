## Instagram Automatic Account Creator Bot

<p>This small piece of code will create an account automatically by randomizing names. You need Selenium library installed. This is an ongoing work. Beware that Instagram has security measures to prevent bot usage. Do not forget to change the Web driver you use from the part of the code in botAccountCreate.py :</p>

```Python
33 browser = webdriver.Chrome("your chrome driver path here")
```
Also, you can use other browsers with tweaking the code.
```Python
#Another browser
26 browser = webdriver.Firefox("your firefox driver path here")
```
<h2>Requirements</h2>
<p> run
<code>
  pip install -r requirements.txt
</code> 
</p>

<h2>New features</h2>

<ul>
  <li>Fake email address</li>
  <li>Getting verification code</li>
</ul> 


<h2>Thank you very much for your support</h2>

<a href='https://github.com/BbChip0103'>BbChip0103</a> <br/>
<a href='https://github.com/haniyadav'>haniyadav</a><br/>
<a href='https://github.com/Gupta-Anubhav12'>Gupta-Anubhav12</a><br/>
<a href='https://github.com/Mxhmovd'>Mxhmovd</a><br/>
<a href='https://github.com/ManWuzi'>ManWuzi</a><br/>
<a href='https://github.com/mikegrep'>mikegrep</a><br/>
<a href='https://github.com/NoNameoN-A'>Alessandro</a><br/>

