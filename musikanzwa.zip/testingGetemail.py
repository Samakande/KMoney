from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager as CM
from selenium.webdriver import ChromeOptions, DesiredCapabilities
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time
#configure pageLoadStrategy to none
#c = DesiredCapabilities.CHROME
#c["pageLoadStrategy"] = "none"
#set chromodriver.exe path
driver = webdriver.Chrome(executable_path=CM().install())#, desired_capabilities=c)

start = time.time()
driver.get("https://mail.tm/")
print(start - time.time())
time.sleep(2)
driver.execute_script("window.stop();")
copy_button = driver.find_element(By.XPATH, """//*[@id="DontUseWEBuseAPI"]""")
copy_button.click()
generated_email = pyperclip.paste()
driver.switch_to.window(driver.window_handles[0])

print(generated_email)

