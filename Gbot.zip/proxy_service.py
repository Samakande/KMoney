Config = {
    "proxy_server" : "input your proxy server"  #213.168.210.76 sample proxy server to prevent instagram's ip ban
}
