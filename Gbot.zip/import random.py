import random

birth_year = random.randint(1990,2003)

for el in birth_year:
    print(el)