from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium.webdriver import ChromeOptions, DesiredCapabilities
from fake_useragent import UserAgent
import accountInfoGenerator as account
import temporaryEmail as tempEmail
from temporaryEmail import color
import randomFiller as rFiller
import getVerifCode as verifiCode
from selenium import webdriver
import fakeMail as email
import sys , os , random , requests , time , pyperclip
import argparse
from webdriver_manager.chrome import ChromeDriverManager as CM
from selenium.webdriver.chrome.options import Options
import csv

ua = UserAgent()
userAgent = ua.random
print(userAgent)

#configure pageLoadStrategy to none
c = DesiredCapabilities.CHROME
c["pageLoadStrategy"] = "none"

options = Options()
#options.add_argument(f'user-agent={userAgent}')
#replace 'your path here' with your chrome binary absolute path
driver = webdriver.Chrome(executable_path=CM().install(), options = options , desired_capabilities=c)
driver.get("https://accounts.google.com/signup/v2/webcreateaccount?service=mail&continue=https%3A%2F%2Fmail.google.com%2Fmail&biz=false&flowName=GlifWebSignIn&flowEntry=SignUp")

time.sleep(8)
try:
    pass
    #cookie = WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '/html/body/div[3]/div/div/button[1]'))).click()
except:
	pass

#generate user credentials
firstName = "Vaenza"
lastName = "Mwaisa"
userName = "mwaisa.more.maenzanise"
acc_password = account.generatePassword()

verifyPhoneNumber = "445577641"

phoneNumber = ""
recoveryEmail = tempEmail.getEmail(driver)
birth_year = str(random.randint(1990,2003))
birth_month = str(random.randint(1,12))
birth_day = str(random.randint(1,30))
gender = str(random.randint(1,2))

#Filling the 1st page 
nameField = driver.find_element(By.XPATH, """//*[@id="firstName"]""")
surnameField = driver.find_element(By.XPATH, """//*[@id="lastName"]""")
emailField = driver.find_element(By.XPATH, """//*[@id="username"]""")
passwordField = driver.find_element(By.XPATH, """//*[@name="Passwd"]""")
confirmField = driver.find_element(By.XPATH, """//*[@name="ConfirmPasswd"]""")

rFiller.fill(nameField, firstName) ; time.sleep(random.uniform(2.95547, 4.41458))
rFiller.fill(surnameField, lastName) ; time.sleep(random.uniform(2.95547, 4.41458))
emailField.clear()
rFiller.fill(emailField, userName) ; time.sleep(random.uniform(2.95547, 4.41458))
rFiller.fill(passwordField, acc_password) ; time.sleep(random.uniform(3.95547, 5.41458))
rFiller.fill(confirmField, acc_password) ; time.sleep(random.uniform(4.378742, 4.85547))
confirmField.send_keys(Keys.ENTER)
time.sleep(8)

try:
    #Phone Number Verification Required, 2nd page
    verifyFonField = driver.find_element(By.XPATH, """//*[@id="phoneNumberId"]""")
    rFiller.fill(verifyFonField, verifyPhoneNumber)
    verifyFonField.send_keys(Keys.ENTER)
    time.sleep(8)

    codeField  = driver.find_element(By.XPATH, """//*[@id="code"]""")
    code = input("Enter The Code")
    rFiller.fill(codeField, code)
    codeField.send_keys(Keys.ENTER)
    time.sleep(8)
except:
    pass

#Filling the 3rd page
phoneField = driver.find_element(By.XPATH, """//*[@id="phoneNumberId"]""")
recoveryEmailField = driver.find_element(By.XPATH, """//*[@name="recoveryEmail"]""")
dayField = driver.find_element(By.XPATH, """//*[@name="day"]""")
yearField = driver.find_element(By.XPATH, """//*[@name="year"]""")
monthField = Select( driver.find_element(By.XPATH, """//*[@id="month"]"""))
genderField = Select( driver.find_element(By.XPATH, """//*[@name="gender"]"""))

#rFiller.fill(phoneField, phoneNumber)
rFiller.fill(recoveryEmailField, recoveryEmail) ; time.sleep(random.uniform(1.95547, 3.41458))
rFiller.fill(dayField, birth_day) ; time.sleep(random.uniform(1.95547, 3.41458))
rFiller.fill(yearField, birth_year) ; time.sleep(random.uniform(1.95547, 3.41458))
monthField.select_by_value(birth_month) ; time.sleep(random.uniform(1.95547, 3.41458))
genderField.select_by_value(gender) ; time.sleep(random.uniform(1.95547, 3.41458))

phoneField.clear() ; time.sleep(random.uniform(2.95547, 3.41458))
phoneField.send_keys(Keys.ENTER)
time.sleep(8)

#Agree to terms of use
Ibutton =  driver.find_element(By.XPATH, """//*[@class="VfPpkd-LgbsSe VfPpkd-LgbsSe-OWXEXe-k8QpJ VfPpkd-LgbsSe-OWXEXe-dgl2Hf nCP5yc AjY5Oe DuMIQc LQeN7 qIypjc TrZEUc lw1w4b"]""")
Ibutton.click()
time.sleep(10)

#Open an email
print("EMAIL SUCCESSFULLY CREATED")


#saves the login & pass into accounts.txt file.
acc = open("Emailaccounts.csv", "a")
writter = csv.writer(acc)
writter.writerow([firstName, lastName, userName, acc_password, verifyPhoneNumber, phoneNumber, recoveryEmail, birth_year, birth_month, birth_day, gender])
acc.close()
