from instapy import InstaPy

InstaPy(username="<your_username>", password="<your_password>").login()

